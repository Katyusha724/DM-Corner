<?php include '../head.php'; ?>
<body>

    <?php include '../navigation-1.php'; ?>

    <div class="container">
       <h1>Sign Up</h1> 
        <p>Signup successful. You can now <a href="../Log-in/login.php">log in</a>.</p> 
    </div>
   
</body>
</html>