<footer>
    <div class="container">
        <p>Made by Petra Kukić Halužan, 2024.</p>
        <p>Tehničko veleučilište Zagreb</p>
    </div>
</footer>